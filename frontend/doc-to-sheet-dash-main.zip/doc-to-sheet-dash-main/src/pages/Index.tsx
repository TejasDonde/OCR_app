import { PdfConverter } from '@/components/PdfConverter';

const Index = () => {
  return <PdfConverter />;
};

export default Index;
